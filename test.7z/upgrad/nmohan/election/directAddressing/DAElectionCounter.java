package com.upgrad.nmohan.election.directAddressing;

import com.upgrad.nmohan.election.AbstractElectionCounter;

/**
 *  Size complexity - > Size of vote array + size of candiadateArray
 * @author nmohan
 *
 */
public class DAElectionCounter extends AbstractElectionCounter {

	private Integer[] voteArray =new Integer[999999];
	private Integer[] candidateStats =new Integer[999];
	
	@Override
	public void addRecord(Integer voterid, Integer candidateId) {
		voteArray[voterid]=candidateId;
		Integer currentpoll=candidateStats[candidateId];
		if(currentpoll==null){
			currentpoll=0;
		}
		currentpoll=currentpoll+1;
		candidateStats[candidateId]=currentpoll;
	}

	@Override
	public Integer findPolledCandidate(Integer voterId) {
		int candidateId=voteArray[voterId]; //Direct Addressing the voteArray, o(n) is 1
		return candidateId;
	}

	@Override
	public Integer countCandidateVotes(Integer candidateid) {
		return candidateStats[candidateid]; //Direct Addressing the voteArray, o(n) is 1
	}
	

}
