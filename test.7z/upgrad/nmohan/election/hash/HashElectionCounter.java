package com.upgrad.nmohan.election.hash;

import java.util.HashMap;
import java.util.Map;

import com.upgrad.nmohan.election.AbstractElectionCounter;

/**
 *
 * @author nmohan
 *
 */
public class HashElectionCounter extends AbstractElectionCounter {

	private Map<Integer,Integer> voteMap =new HashMap<Integer,Integer>(1000);
	private Map<Integer,Integer> candidateStatMap =new HashMap<Integer,Integer>(100);
	
	@Override
	public void addRecord(Integer voterid, Integer candidateId) {
		voteMap.put(voterid, candidateId);
		candidateStatMap.merge(candidateId, 1, Integer::sum);
	}

	@Override
	public Integer findPolledCandidate(Integer voterId) {
		return voteMap.get(voterId);
	}

	@Override
	public Integer countCandidateVotes(Integer candidateid) {
		return candidateStatMap.get(candidateid);
	}

}
