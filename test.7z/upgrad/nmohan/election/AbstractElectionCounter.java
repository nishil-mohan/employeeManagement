package com.upgrad.nmohan.election;

public abstract class AbstractElectionCounter {

	
	public abstract void addRecord(Integer voterid, Integer candidateId);
	
	public  abstract Integer findPolledCandidate(Integer voterId);
	
	public  abstract Integer countCandidateVotes(Integer candidateid);
	
	
}
