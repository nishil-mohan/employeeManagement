package com.upgrad.nmohan.election;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.upgrad.nmohan.election.directAddressing.DAElectionCounter;
import com.upgrad.nmohan.election.hash.HashElectionCounter;

public class ElectionCounterApp {

	public static void main (String s[]){
		
		ElectionCounterApp counterApp=new ElectionCounterApp();

		System.out.println("Choose the datastructure for the operation. Choose 1 or 2");
		System.out.println("1 - Direct Addressing");
		System.out.println("2 - Hash");
		Scanner scanner =new Scanner(System.in);
		
		AbstractElectionCounter electionCounter =resolveElectionCounter(scanner);
		//Load the file. 
		System.out.println("Loading the File - ");
		File file = counterApp.loadFile();
		try (Scanner fileScanner = new Scanner(file)) {
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine(); 
				System.out.println(line);
				String[] recordArray=line.split("\t");
				int voterId=Integer.parseInt(recordArray[0]);
				int candidateId=Integer.parseInt(recordArray[1]);
				electionCounter.addRecord(voterId,candidateId);
			}
			fileScanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Loaded");
		while(true){
			System.out.println("Enter voterId-Press 0 to exit");
			int selection=scanner.nextInt();
			if(selection==0){
				break;
			}else { 
				Integer candidateId=electionCounter.findPolledCandidate(selection);
				if(candidateId!=null){
					System.out.println("Candidate Id is - "+candidateId);
				}else{
					System.out.println("Invalid selection.");
				}
			}
		}
		while(true){
			System.out.println("Enter candidateId for the poll statistics-Press 0 to exit");
			int selection=scanner.nextInt();
			if(selection==0){
				break;
			}else { 
				Integer pollCount=electionCounter.countCandidateVotes(selection);
				if(pollCount!=null){
					System.out.println("Poll Count is - "+pollCount);
				}else{
					System.out.println("Invalid selection.");
				}
			}
		}
		scanner.close();
	}

	/**
	 *   
	 * @param scanner
	 * @return
	 */
	private static AbstractElectionCounter resolveElectionCounter(Scanner scanner) {
		while(true){
			int selection=scanner.nextInt();
			if(selection==1){
				return new DAElectionCounter();
			}else if(selection==2){
				return new HashElectionCounter();
			}else{
				System.out.println("Invalid selection. Please choose 1 or 2");
			}
		}
	} 
	
	/**
	 * 
	 * @return
	 */
	private   File loadFile(){
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("resources/data.txt").getFile());
		return file;
	}
}
