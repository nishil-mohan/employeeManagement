
1. Java 8 should be installed in your system
2. Application will run in port 8080. If this port is blocked in your corporate network, you can
   change port by updating runApplication.bat (--server.prt==%port%)
3. Execute standalone.bat
4. Once application launched, open url http://localhost:8080